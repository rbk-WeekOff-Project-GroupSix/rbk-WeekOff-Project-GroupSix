import React from "react";
import ReactDOM from "react-dom";

class Trans extends React.Component {
  render() {
    const { TransArr } = this.props;
    return (
      <div>
        <ul>
          {TransArr.map((element, index) => (
            <li>
              {element.expensesTypes}....{element.amount} ...{element.createdAt}
            </li>
          ))}
        </ul>
      </div>
    );
  }
}
export default Trans;
