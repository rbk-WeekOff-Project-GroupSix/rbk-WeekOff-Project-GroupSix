//عمل جدول لعرض العمليات

import React, { Component } from "react";
class List extends Component {
  render() {
    return (
      <div>
        <h1> Transications </h1>
      </div>
    );
  }
}
export default List;
