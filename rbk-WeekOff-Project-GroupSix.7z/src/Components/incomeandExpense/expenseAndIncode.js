//لعرض قيمة الفلوس من الواردات والصادرات 
import React, { Component } from 'react';
import "./style.css"
var ExpenseAndIncome = ( ) =>{
    return (
    <div>
    <span id ="ex" >expence 0</span> <span id ="incode">income 0</span>
    </div>
    )
}
export default  ExpenseAndIncome ;