import React, { Component } from 'react';

class Home extends Component {
    render() {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', padding: 30 }}>
                <div><h2>Home Page</h2></div>
            </div>
        );
    }
}

export default Home;